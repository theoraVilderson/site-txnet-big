---
id: conventions
status: active
updated: YYYY-MM-DD
---

# House style

Rules about **how code is written**, as opposed to what it does. Business rules
live in a unit's `rules.md`; those are about the product. These are about the
codebase, and they apply everywhere.

Read at tier 4 — before writing code inside any unit.

## The format

Every convention gets a permanent id (`C-nn`), cited in review and in commit
messages the same way a catalog id is. The `enforced by` column is the honest
part of this file: it shows at a glance which rules are actually held and which
ones are only hoped for.

| enforced by | means |
|---|---|
| `check` | `python3 tools/conventions.py` fails on a violation |
| `lint` | your linter fails on it (rule named in the notes) |
| `review` | nothing enforces it. It will be violated eventually. |

A convention that keeps getting violated does not need a firmer sentence. It
needs to move up that table.

## Conventions

| id | rule | enforced by |
|---|---|---|
| _C-01_ | _Comments explain **why**, never what. If a comment restates the code, delete the comment or rename the thing._ | _review_ |
| _C-02_ | _No raw `try`/`catch`. Anything that can throw goes through `safeExecute()`._ | _check_ |
| _C-03_ | _Money is integer minor units. Never a float, never a formatted string, outside the presentation layer._ | _check_ |

Delete the rows above and write your own. Keep this list short — a style guide
nobody can hold in their head is a style guide nobody follows.

---

## C-02 — `safeExecute` instead of raw try/catch

**Rule.** Every call that can throw is wrapped in `safeExecute()`. A bare
`try`/`catch` in application code is a violation.

**Why.** One wrapper means error shape, logging and the retry decision are
decided in one place instead of re-invented at every call site. Scattered
`catch` blocks are how a codebase ends up with four different error formats and
one that silently swallows.

```ts
// wrong
try {
  const res = await gateway.charge(amount);
  return res;
} catch (e) {
  logger.error(e);
  throw e;
}

// right
return safeExecute(() => gateway.charge(amount), { op: "gateway.charge" });
```

**Where it may not apply.** `safeExecute`'s own implementation, and the
top-level process handler. Both are in the `except:` list below — extend it
deliberately, never by loosening the pattern.

```check C-02
forbid: \btry\s*\{
in: apps/**/*.ts, apps/**/*.tsx
except: apps/api/src/platform/safe/**, apps/api/src/main.ts
message: no raw try/catch — wrap the call in safeExecute() (C-02)
```

**If you use ESLint**, enforce it there too — it fires in the editor, which is
better than firing in CI:

```js
// eslint.config.js
{
  rules: {
    "no-restricted-syntax": ["error", {
      selector: "TryStatement",
      message: "No raw try/catch — use safeExecute() (C-02, docs/CONVENTIONS.md)."
    }]
  }
}
```

---

## C-01 — comments explain why

**Rule.** A comment carries the reason, the constraint, or the thing that is not
visible in the code. It never restates the line below it.

**Why.** A comment that describes *what* the code does is duplicated truth, and
duplicated truth drifts — the code gets edited, the comment does not, and now
the comment is a lie that reads with authority. A comment about *why* survives
the rewrite, because the reason outlives the implementation.

```ts
// wrong — restates the code, and will be wrong after the next edit
// increment the retry counter
retries += 1;

// right — the reason, which the code cannot show
// The gateway rate-limits per merchant, not per request, so a shared
// counter here is deliberate. See ADR-0007.
retries += 1;
```

**Not mechanically checkable**, and it should not pretend to be: no regex can
tell a good comment from a bad one. This one lives or dies in review — which is
exactly why it is worth stating once, precisely, instead of as "write good
comments".

---

## C-03 — money is integer minor units

**Rule.** Amounts are integers in the currency's minor unit (cents, rials).
Floats and formatted strings exist only in the presentation layer.

**Why.** `0.1 + 0.2 !== 0.3`. In a ledger that is not a rounding curiosity, it
is a balance that will not reconcile, discovered months later.

```check C-03
forbid: (amount|price|balance|total)\s*:\s*(number|float|double)\b
in: apps/api/**/*.ts
except: apps/api/src/presentation/**
message: money is an integer minor unit — use a branded Minor type, not a raw number (C-03)
```

The regex above is a *tripwire*, not a proof. It catches the common shape and
misses clever ones, and that is the right trade: a cheap check that fires on the
usual mistake beats an expensive one that nobody runs.
