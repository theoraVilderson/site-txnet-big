---
id: dependency-graph
status: draft
updated: YYYY-MM-DD
---

# Dependency graph

Two kinds of edge, kept apart on purpose.

## Static edges — `depends_on`

GENERATED. `python3 tools/docs-check.py` prints the consumer map from every
unit's `depends_on` front matter. Nothing is written by hand here.

`depends_on` answers **"who do I call"**. It is what `00-PROTOCOL.md` §8 uses to
compute blast radius, so every entry in it widens the consumer list of a
contract change. Keep it honest and keep it small.

## Runtime edges — what `depends_on` cannot see

A queue, a webhook, a cron job and a domain event all move control between units
without either one importing the other. `depends_on` is blind to them, which
means a walk (§3c) that only follows static edges will silently miss an entire
class of bug — and miss it confidently.

These are **not** merged into `depends_on`. A runtime edge answers **"what runs
after me"**, which is a debugging question, not a contract question. Merging the
two would inflate every consumer list and make every additive change look
breaking.

Start empty. Add a row the first time a walk needs it — the same lazy rule as
MODE: INGEST. An edge you never debug across costs you nothing.

| from | to | via | why |
|---|---|---|---|
| _billing_ | _notification_ | _queue: invoice.created_ | _receipt email is sent by a worker, not by billing_ |

Delete the example row. `tools/where.py` reads this table by heading, so keep
the `## Runtime edges` heading and the four column names exactly as they are.

## Manual notes

Anything the two tables above cannot express — a fan-out, a retry topology, a
third-party callback that re-enters the system — goes here in prose, briefly.

```
```
