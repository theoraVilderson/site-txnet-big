---
id: surfaces
status: active
updated: YYYY-MM-DD
code_roots:
  - apps/panel/src
  - apps/api/src
---

# Surface map — what the user can point at

`MASTER_INDEX.md` answers *"which unit owns this concern?"*. This file answers
the question a user actually asks: **"edit the profile button in the panel"** —
a thing they can see, named in their own words, with no path attached.

One row per user-visible surface: a screen, a tab, a button, a form, a bot
command, a public endpoint. Resolve a row with:

```bash
python3 tools/where.py "edit the profile button in the panel"
```

Never make the user say a path. If they had to, this file is missing a row.

## Rules

- `surface` — kebab-case, permanent, unique. It is an **id**, not a label.
- `aliases` — comma-separated, in the words a person actually types, including
  the sloppy short forms. This column is the whole point of the file; a row
  without aliases will never be found by a human's own phrasing. **Add an alias
  the moment a query misses.** If you also prompt in a second language, put
  those words here too — `tools/where.py` normalises Persian/Arabic script.
- `unit` — must exist in `MASTER_INDEX.md`. A surface with no owning unit is a
  BLOCKING question (`00-PROTOCOL.md` §9), not a row to invent.
- `component` — a real path or glob, checked by `python3 tools/where.py --check`.
  This is the **only** place a UI path is written down.
- `spec ref` — the catalog id, never a line range. `—` if the surface predates
  the catalog.
- One surface = one thing a person can point a finger at. A page with six
  independent controls is one row for the page **plus** a row for each control
  that gets edited on its own.
- Never delete a row. A removed surface keeps its id and gets `(removed)` in the
  note, for the same reason a catalog id is never deleted.

## Panel

| surface | aliases | route | unit | component | spec ref | note |
|---|---|---|---|---|---|---|
| _panel-profile-edit_ | _profile button, edit profile, profile, account button_ | _/panel/settings/profile_ | _panel_ | _apps/panel/src/features/profile/EditProfileButton.tsx_ | _F-0111_ | _delete this row_ |

## API

| surface | aliases | route | unit | component | spec ref | note |
|---|---|---|---|---|---|---|
| | | | | | | |

## Bot / other

| surface | aliases | route | unit | component | spec ref | note |
|---|---|---|---|---|---|---|
| | | | | | | |

## Flows

A surface is a thing you point at. A flow is a **behaviour that crosses units**:
logging in with a cookie touches the panel, the auth unit and the session
platform unit. `where.py --walk` derives that chain from `depends_on` plus the
runtime edges every time it is asked. This table is the cache.

**Never write a flow row in advance.** A row written before the walk is a guess
at which files matter, and it will be wrong in the most expensive way — it looks
like knowledge. Rows are written **after** a fix, from the path actually taken,
by MODE: DIAGNOSE (`00-PROTOCOL.md` §6g) step 7. Then the second time someone
reports the same thing, there is no walk at all.

- `flow` — kebab-case, permanent, unique. An id, like a surface.
- `aliases` — **the user's own sentence, verbatim**, including the symptom
  words. This is the row's whole value: it is how the same complaint, phrased
  the same careless way, lands directly on the answer next time.
- `path` — the unit chain, `->` separated, in the order the walk took it.
  Every id must exist; `where.py --check` fails otherwise.
- `files` — comma-separated, only the files the fix actually touched. Not the
  files that were read. A flow row is evidence, not a reading list.
- Never delete a row. A flow that stops existing keeps its id and gets
  `(removed)` in the note.

| flow | aliases | path | files | spec ref | note |
|---|---|---|---|---|---|
| _cookie-login_ | _cookie login doesn't work, لاگین کوکی کار نمیکنه, stays logged out_ | _panel -> auth -> session_ | _apps/api/src/platform/session/cookie.ts_ | _F-0101_ | _delete this row_ |
