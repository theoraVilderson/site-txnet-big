---
id: code-layout
status: active
updated: YYYY-MM-DD
---

# Code layout — the mirror rule

The docs tree already has stable ids. This file makes the **code tree carry the
same ids**, so a path is derived, never remembered.

> **The mirror rule: a unit id is a folder name. One unit, one folder, one owner.**

```
docs/domains/billing/        <->   apps/api/src/modules/billing/
docs/interfaces/panel/       <->   apps/panel/src/
docs/platform/notification/  <->   apps/api/src/platform/notification/
```

Given `unit: billing`, the code is at `<backend-root>/modules/billing/**`. No
lookup table. `source:` in the unit's front matter is the authoritative copy of
that path, and `tools/docs-check.py` fails if it does not resolve — so the
mirror cannot silently break.

## The three roots

Fill these in for this project, once. Everything else follows.

| root | holds | mirrors |
|---|---|---|
| `apps/api/src/modules/<unit>/` | domain units — rules + state | `docs/domains/<unit>/` |
| `apps/api/src/platform/<unit>/` | cross-cutting, no business rules | `docs/platform/<unit>/` |
| `apps/panel/src/features/<surface-group>/` | UI surfaces | `docs/SURFACES.md` rows |

Register them in `docs/SURFACES.md` front matter as `code_roots:` so
`tools/where.py` can fall back to a filename scan when a surface row is missing.

## Inside a domain unit

Same file names in every unit, so "where is the validation for X" has one
answer everywhere:

```
modules/billing/
  billing.controller.ts     transport only. no rules. mirrors interfaces/.
  billing.service.ts        the rules in rules.md live here
  billing.repository.ts     the only file that touches billing's tables
  billing.types.ts          the shapes in contract.md
  billing.invariants.ts     runtime guards for invariants.md, named INV_xx
  __tests__/
```

Two things that make audits mechanical:

- A guard in `*.invariants.ts` is named after the invariant it enforces
  (`INV_01_entriesSumToZero`). Grep the id, find the enforcement, or prove there
  is none.
- A repository file is the **only** place its own tables appear. `owns_tables`
  in the front matter is then checkable by grep: another unit's repository
  naming your table is the §8 violation, visible in one search.

## Symptom -> role — how to narrow *inside* a unit

The tiers in `00-PROTOCOL.md` §3 narrow down to a unit and stop. For a unit with
thirty files that is not narrow at all, and it is exactly where an agent starts
reading everything. This table is the last step of the funnel: it maps what
broke to which of the canonical files above is likely to hold it.

**This table is project-specific and you own it.** The roles below are the
NestJS-ish split this skeleton ships with; a Django project reads
`views / models / serializers`, a Go one `handler / usecase / store`. Rewrite
the right-hand column in your own file names. That is why this lives here and
not in the fixed protocol.

| symptom | look in | do not start in |
|---|---|---|
| 401 / 403 / wrong permission | `*.guard.ts`, platform auth middleware | the service |
| 400 / bad request / validation | `*.controller.ts`, `*.types.ts` | the repository |
| endpoint 404, route not firing | `*.controller.ts`, the router registration | anything else |
| right shape, wrong values | `*.service.ts` | the controller |
| correct in the API, wrong on screen | the panel component + its `use<Thing>.ts` | the API unit |
| data written wrong, or not written | `*.repository.ts` | the service |
| works once then fails / state leaks | `*.invariants.ts`, then the store or cache | the controller |
| slow | the repository (queries), then the queue edges | the service |
| works locally, fails deployed | `docs/operations/`, env + config | any unit at all |

Two rules that matter more than the table:

- **Read the role, not the folder.** One file per hop. If the file you predicted
  does not contain the bug, that is information — say so out loud and pick the
  next role deliberately. It is not a reason to open the other nine.
- **A symptom that fits no row is a finding.** Either the table is missing a row
  (add it) or the unit is doing something its file names do not admit to, which
  is a `CONVENTIONS.md` problem, not a debugging one.

## Panel / UI

```
apps/panel/src/features/<group>/
  <Group>Page.tsx           the route
  <Thing>Button.tsx         a surface row points here
  use<Thing>.ts             data access, calls the API unit
```

The component filename is what the user is pointing at, so it must contain the
noun they say. `EditProfileButton.tsx`, not `Btn2.tsx` — the filename scan in
`tools/where.py` is the safety net when `SURFACES.md` has a gap, and it can only
match words that are actually in the name.

## Commits

`feat(billing): ...` — scope is the **unit id**, always. Body carries
`spec: F-0207`. Now `git log --grep 'spec: F-0207'` answers "when was this
built, and by which change" without anyone maintaining a link.

## What this buys

| question | answered by | cost |
|---|---|---|
| where does unit `X` live? | the mirror rule | zero — it is derivable |
| where is the thing the user just described? | `tools/where.py "<their words>"` | one command |
| which code proves feature `F-xxxx`? | backlog `proof` column + `git log --grep` | zero |
| did this change break a consumer? | `depends_on` reverse lookup | one grep |

## What breaks it

- A folder that is not a unit and not in a root above. If it needs a home,
  it needs a unit — or it belongs inside an existing one.
- A shared `utils/` that grows business rules. The moment a rule lands there it
  is a `platform/` unit with a contract, or it goes back where it came from.
- A UI component reaching an API unit's tables directly. Cross-unit access goes
  through `contract.md` (`00-PROTOCOL.md` §8). No exceptions, no shortcuts.
