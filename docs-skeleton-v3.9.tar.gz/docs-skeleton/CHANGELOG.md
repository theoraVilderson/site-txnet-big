# Changelog

## v3.9 — the scale fixes

v3.8 capped the INDEX changelog at 5 rows to resolve a collision between a
mandatory changelog and a hard 40-line cap. That was the wrong thing to bound.
Measured against a realistic mature unit — 8 keywords, 4 `source:` globs, 8
owned tables, 8 dependencies — the file hits exactly 40/40 **with the changelog
already at its cap**. The next legitimate edit has no legal move. All three bugs
below only fire once a project is large, which is when they cost the most.

- **The cap now applies to the INDEX body, not the file.** Front matter is not
  content; it is mandatory metadata whose length is set by how many things the
  unit genuinely depends on, owns and exposes. Counting it meant a mature unit
  hit the ceiling with an empty body. The 5-row changelog cap stays — it is
  still what keeps a router a router — but it is no longer competing with
  metadata for the same budget.

- **A wrapped `[...]` list silently destroyed the graph.** Both parsers only
  handled a bracket list that opened and closed on one line. Wrapping is exactly
  what you do once a list is long, so the failure was reserved for the units
  that could least afford it. `docs-check.py` iterated the string character by
  character and emitted 70 lines of `depends_on unknown unit 'i'`; `where.py`
  was quieter and worse, collapsing eight edges into one bogus id, so the walk
  lost every edge of that unit without a word. Both now read a wrapped list, and
  §2 states the rule.

- **Bounded contexts were impossible to satisfy.** §10 tells you to group units
  once you pass 12 top-level ones, and says the parent "keeps only the INDEX" —
  but every checker treated that parent as a unit and demanded a `layer`, a
  `contract.md` and a `source:`. Following the protocol's own scaling advice
  made the audit fail with no legal fix. `layer: group` now marks a router over
  units; `docs-check.py` validates it as one (no code, must have sub-units) and
  `where.py` keeps it out of the walk.

**Measured effect** on a bug in a 30-file module: the walk reads its own output,
one unit INDEX and one predicted file per hop — roughly 1.8k tokens against
~12k for reading the module. The saving comes from the prediction gate, not the
tool: the budget is what stops a hop from becoming a sweep.

## v3.8 — audit fixes

Ten reported bugs, all reproduced, plus two found while testing the fixes. Three
of the ten were introduced by v3.7; the rest had been there since v2.

**BLOCKER — the 40-line cap made history mandatory *and* impossible**

§10 caps `INDEX.md` at 40 lines and `docs-check.py` errors on it, while §5.4 and
§6b.6 require a changelog line on every change. No archive path was ever
defined — `archive`, `prune` and `history` do not appear in the protocol at all.
A unit at 40/40 could not be edited again without silently deleting history.

An unbounded append cannot coexist with a hard cap, so one rule had to give, and
it was not the cap: a router that has grown a history is no longer a router.
**The changelog now keeps its last 5 rows and older ones are deleted, not
archived.** There is deliberately nowhere to archive to — git already holds every
row (`git log --follow docs/domains/<unit>/`), and keeping a second copy in the
INDEX is exactly the §0 violation the protocol opens with. The INDEX error
message now says which of the two things overflowed.

**HIGH**

- `drift.py` skipped `.proto`, `.json`, `.yaml`, `.graphql` and `.toml` — three
  of the four formats §0 ranks as *authority #1*. A unit whose `source:` was all
  JSON or all proto could never report drift; the tool was blind in exactly the
  files the protocol trusts most. Added, with a lockfile/minified skip list so
  one `package-lock.json` churn cannot drown the report.
- Reachability in `docs-check.py` was `uid not in mtext` — a substring test. A
  unit with `id: ai` passed while entirely absent from `MASTER_INDEX.md`,
  because "ai" occurs inside "domains". Short ids are the ones real projects
  use (`ai`, `ui`, `db`, `i18n`), so the check silently exempted them. Now
  matches the id cell of a table row or a link target.

**MEDIUM**

- §2 requires front matter on every unit file; only `INDEX.md` was ever parsed,
  so a broken header on `contract.md` passed all five checkers — the file §0
  ranks as intent. Now checked, including that its `id` matches the unit's.
- `(removed)` is now a **state**, not a comment: `where.py --check` stops
  demanding a component path for such a row. The old behaviour emitted a
  permanent, unactionable warning, and a report with one of those in it stops
  being read.
- Two wrong cross-references, both since v2: §5.3 pointed contract changes at
  §7 (AUDIT) instead of §8, and §5.5 pointed uncertainty at §8 instead of §9.
- Section order is now canonical (`3b` before `3c`; `6b`–`6g` in sequence), and
  the tier table's `0a`/`0b` rows sit above tier 0, matching what §3b and §3c
  say about themselves. v3.7 inserted `3c` and `6g` in the wrong places.

**LOW**

- `MAX_CONTRACT_LINES = 250` vs "~200" in §10 — the gap is real and now stated:
  ~200 is where you should split, 250 is where you lose the choice. A hard error
  at the advisory number turns every contract into a fight with the linter.
- `spec.py`'s not-found message accused you of renumbering. Backlog ids and
  catalog ids share the `F-` prefix, so the likeliest cause is passing a row's
  `id` where its `spec ref` belongs. It now says that first.
- `backlog.py` printed "everything is done, blocked, or waiting on a decision"
  next to `blocked: 0`. It now names which of the three it actually is, and
  lists the unmet dependency per row.

**Found while testing the above**

- `backlog.py` never detected duplicate row ids, though `docs-check.py` has
  always rejected duplicate unit ids. Two rows sharing an id double every count
  and name the same item twice in the eligible list — which is how it surfaced.
- Flow rows were competing on plain locate queries: `login form` resolved to the
  recorded `cookie-login` flow because both contain "login". One recorded bug
  path could hijack every request sharing a word with it. Flows now enter the
  pool only when the sentence reports a symptom.

## v3.7 — the walk

v3.2 gave a vague request an address. It could not give a *bug report* one,
because a bug report names no address: "cookie login doesn't work" is a symptom
plus a guess. v3.2 scored those against each other and returned a shortlist of
rivals — measured on a real tree, even an exact query like `login form` came
back as `candidates`, never `confident match`. An agent handed a shortlist reads
its way out of it, which is how "the cookie login is broken" became "read every
file under auth".

**New**

| file | what it does |
|---|---|
| `docs/00-PROTOCOL.md` §3c | WALK — the read protocol for a request that names a symptom instead of a place |
| `docs/00-PROTOCOL.md` §6g | `MODE: DIAGNOSE` — a bug report finally has a mode, so it stops falling through to the agent's own default |
| `docs/SURFACES.md` `## Flows` | cached walks. Written *after* a fix, from the path actually taken. Never authored in advance |
| `docs/architecture/dependency-graph.md` `## Runtime edges` | queues, webhooks, cron — the edges `depends_on` cannot see |
| `docs/CODE-LAYOUT.md` symptom -> role | which *file* in a unit, not just which unit. Project-owned, like `CONVENTIONS.md` |
| `docs/.where-misses` | a queue of queries that found nothing. `where.py --check` fails while one is open |
| `.claude/commands/diagnose.md` | `/diagnose <symptom>` |

**Changed — `tools/where.py`**

- **A surface row now dominates the unit it points at** instead of tying with
  it. Install step 6 asks you to fill both a surface's `aliases` and its unit's
  `keywords` with the words you would actually say, which guaranteed the two
  scored alike — that, not the threshold, is why `confident match` almost never
  fired. The unit is still reachable, through the surface, which is strictly
  more specific.
- `--walk` splits the sentence into **locator** and **hypothesis**. The locator
  picks the entry point; the hypothesis only orders the frontier. Which token is
  which is decided from the data — whatever the winning row already explains is
  the locator — not from a word list, because `cookie` is a symptom in one
  project and a unit name in another.
- The walk follows `depends_on` **and** runtime edges, to `MAX_HOPS`.
- A cached flow only short-circuits on a genuine repeat: two matched tokens and
  60% of the ceiling. One shared word between two different symptoms is not the
  same bug, and a stale path served for a new problem is worse than deriving
  one — it arrives looking confirmed.
- `--misses` / `--resolve` manage the queue; `--check` fails on an open entry.

**Unchanged on purpose**

`depends_on` is not merged with runtime edges. The first answers "who do I
call" and drives §8 blast radius; the second answers "what runs after me" and
drives the walk. Merging them would inflate every consumer list and make every
additive change look breaking.

A walk never creates a unit. Code it meets that no unit claims is reported and
left alone — unit boundaries are the most expensive thing in this repo to get
wrong, and the moment you first meet a folder is the worst moment to draw one.
`MODE: SYNC` (§6f) owns that call, with the user.

**Upgrading from v3.6**

```bash
cp tools/where.py                          your-project/tools/
cp docs/00-PROTOCOL.md                     your-project/docs/     # v2.4 -> v2.5
cp .claude/commands/diagnose.md            your-project/.claude/commands/
```

Then, by hand, because these hold your content: add the `## Flows` section to
`docs/SURFACES.md`, the `## Runtime edges` table to
`docs/architecture/dependency-graph.md`, and the symptom -> role table to
`docs/CODE-LAYOUT.md` — rewriting its right-hand column in your own file names.
Both new tables start empty and fill lazily. `python3 tools/where.py --check`
should exit 0 on a fresh upgrade.

## v3.6 — house style

Project rules about *how* code is written had nowhere to live except a bullet in
`AGENTS.md`, where they compete for context with everything else and get
followed most of the time. v3.6 gives them a home and, where possible, teeth.

**New**

| file | what it does |
|---|---|
| `docs/CONVENTIONS.md` | one row per convention, each with a permanent `C-nn` id and an honest `enforced by` column |
| `tools/conventions.py` | runs the `check` blocks declared inside that file. No lint toolchain, no dependencies, any language |

**Changed**

- `docs/00-PROTOCOL.md` -> v2.4. `CONVENTIONS.md` added to tier 4 (read before
  writing code inside a unit) and to §1, plus a hard rule in §11: never route
  around a convention to make something work — name the id and ask.
- `AGENTS.md` — a House style section; the pre-flight list is now five commands.
- `README.md`, `docs/PROMPTS.md`, `docs/MASTER_INDEX.md`, `/audit`.

**How a convention declares its own check**

````markdown
```check C-02
forbid: \btry\s*\{
in: apps/**/*.ts, apps/**/*.tsx
except: apps/api/src/platform/safe/**
message: no raw try/catch — wrap the call in safeExecute() (C-02)
```
````

`forbid` or `require`, a glob to scan, an `except` list, and a remedy. A
violation with no stated remedy is noise, so `message` is mandatory.

**The `enforced by` column**

`check` / `lint` / `review`. The point of the column is that it admits which
rules nothing holds. `python3 tools/conventions.py --list` prints the split.
A convention that keeps getting violated does not need a firmer sentence — it
needs to move up that table.

Not everything can move. "Comments explain why, not what" is not checkable by
any regex, and the file says so rather than shipping a check that half-works.

**Upgrading from v3.5**

```bash
cp docs/CONVENTIONS.md   your-project/docs/
cp tools/conventions.py  your-project/tools/
cp docs/00-PROTOCOL.md   your-project/docs/     # v2.3 -> v2.4
```

Then delete the example rows and add your own. Move any style bullets currently
in `AGENTS.md` into `CONVENTIONS.md`, leaving `AGENTS.md` small — it is loaded
on every turn.

## v3.5 — MODE: SYNC

You code for a week without an agent. New files, moved files, a whole new
module. When the agent comes back, the docs are behind and nobody knows by how
much. v3.5 measures that gap instead of guessing at it.

**New**

| file | what it does |
|---|---|
| `tools/drift.py` | diffs the code against `docs/.sync` and prints an exact work order |
| `.claude/commands/sync.md` | `/sync` |
| `docs/.sync` | the last commit at which docs and code agreed. Created by `--init`, committed like any other doc |

**Changed**

- `docs/00-PROTOCOL.md` -> v2.3, new §6f (MODE: SYNC).
- `AGENTS.md`, `CLAUDE.md`, `README.md`, `docs/PROMPTS.md`,
  `docs/MASTER_INDEX.md`.

**What the report gives you**

Sorted so that each finding is fixed before the ones it would otherwise
invalidate:

1. **Ambiguous ownership** — a `source:` glob that does not contain its own unit
   id. This breaks the mirror rule, silently claims other units' code, and hides
   every orphan inside itself. Nothing below it is trustworthy until it is
   narrowed, which is why it prints first.
2. **Orphans** — code no unit claims. The finding that actually matters.
3. **Broken references** — `source:` and `SURFACES.md` paths that no longer
   resolve.
4. **Likely new surfaces** — new user-visible files with no `SURFACES.md` row.
5. **Spec ids cited in commits** — candidate backlog rows, to verify not assume.

Works without git too, falling back to file mtimes against the marker date —
less reliable, and it says so.

**The limit, stated plainly**

`drift.py` sees *what* changed, never *why*. It cannot tell a domain unit from a
platform one, and it cannot read an invariant out of an implementation: what
code does is not what it must do. So MODE: SYNC asks rather than invents, and
`--update-marker` is never run on your behalf — the marker asserts that docs and
code agree, and only you can confirm that.

**Upgrading from v3.4**

```bash
cp tools/drift.py            your-project/tools/
cp .claude/commands/sync.md  your-project/.claude/commands/
cp docs/00-PROTOCOL.md       your-project/docs/     # v2.2 -> v2.3
cd your-project && python3 tools/drift.py --init
```

Run `--init` at a point where the docs are actually correct — after a
`/reconcile` or an `/audit` that came back clean, not before.

## v3.4 — portability

Nothing here was ever Claude-specific — plain Markdown and dependency-free
Python — but the wiring was. v3.4 makes the rules load on any tool, and adds a
path for models that have no filesystem at all.

**New**

| file | what it does |
|---|---|
| `AGENTS.md` | the canonical rules file, read natively by Codex, Cursor, Copilot, Gemini CLI, Aider, Zed and others |
| `docs/AGENT-SETUP.md` | per-tool setup, the no-shell workflow, and what to do about weaker models |
| `tools/context.py` | a paste-ready session bundle for a chat window or a raw OpenRouter call |

**Changed**

- `CLAUDE.md` is now one `@AGENTS.md` import plus Claude Code's slash-command
  list. Claude Code does not read `AGENTS.md`, and duplicating a rules file is
  how two rules files start disagreeing.
- `README.md`, `docs/MASTER_INDEX.md`.

**The two cases**

*Agent with a shell* (Claude Code, Cursor, Codex, Cline, Aider, Zed) — point its
rules file at `AGENTS.md` once and attach nothing ever again. It runs `spec.py`
and `where.py` itself.

*No shell* (chat window, OpenRouter API) — `python3 tools/context.py --lean`
prints ~3k tokens of protocol digest, master index, backlog and live handoff.
Paste once per session. When the model needs a spec or a path, it asks and you
run one command. It is told never to ask for the catalog.

**What does not port**

The protocol works by obedience, not by locks. A cheap model will grep the repo
the moment it feels lost and pull the whole catalog into context.
`AGENT-SETUP.md` gives the mechanical answer: split the catalog by area (the
tooling already globs `App-Features*.md`), or keep it outside the agent's working
directory so it cannot be opened by accident.

**Upgrading from v3.3**

```bash
cp AGENTS.md CLAUDE.md   your-project/
cp docs/AGENT-SETUP.md   your-project/docs/
cp tools/context.py      your-project/tools/
```

If your `CLAUDE.md` has project-specific edits, move them into `AGENTS.md` and
leave `CLAUDE.md` as the `@AGENTS.md` pointer.

## v3.3 — the session boundary

A session fills up mid-feature. Everything you and the agent worked out in it —
what is half-written, what you already tried and it failed, what you decided out
loud — dies with the window. v3.3 carries exactly that across, and nothing else.

**New**

| file | what it does |
|---|---|
| `docs/HANDOFF.md` | mid-item state. Overwritten every time, never appended to, reset to `empty` when the item lands |
| `.claude/commands/handoff.md` | `/handoff` — stop cleanly and write the state down |
| `.claude/commands/resume.md` | `/resume` — pick it back up in a fresh session |

**Changed**

- `docs/00-PROTOCOL.md` -> v2.2. New §6e (HANDOFF / RESUME), `HANDOFF.md` in §1,
  and §6b step 7 now says to hand off rather than force an item closed.
- `tools/backlog.py` — reports an active handoff, and **fails** on one that
  outlived its item. A stale handoff is worse than none: the next session trusts
  it.
- `CLAUDE.md`, `README.md`, `docs/PROMPTS.md`, `docs/MASTER_INDEX.md`.

**Why**

`BACKLOG.md` + `MASTER_INDEX.md` were already the complete resume state
*between* items. They say nothing about the inside of one. Without a handoff, a
fresh session re-derives the half-finished design, walks into the same dead ends
in the same order, and silently loses every decision that was only ever spoken.

**Upgrading from v3.2**

```bash
cp docs/HANDOFF.md            your-project/docs/
cp docs/00-PROTOCOL.md        your-project/docs/     # v2.1 -> v2.2
cp tools/backlog.py           your-project/tools/
cp .claude/commands/handoff.md .claude/commands/resume.md  your-project/.claude/commands/
```

Nothing else needs to change.

## v3.2 — the addressing layer

You point at a thing; the agent finds the file. No paths, no grep.

**New**

| file | what it does |
|---|---|
| `docs/SURFACES.md` | one row per user-visible surface: id, aliases in your own words, route, unit, component path, spec id |
| `docs/CODE-LAYOUT.md` | the mirror rule — a unit id is a folder name, so paths are derived rather than remembered |
| `tools/where.py` | a human sentence -> unit, doc, code path, spec id, next commands. `--check` validates every surface still points at a real file |
| `.claude/commands/where.md` | `/where <description>` |

**Changed**

- `docs/00-PROTOCOL.md` -> v2.1. New §3b (LOCATE), tier 0b in §3, `SURFACES.md`
  and `CODE-LAYOUT.md` in §1, a surface-upkeep step in §6, `where.py --check` in
  §7, and two hard rules in §11: never grep to locate a feature, never write a
  path the tooling did not produce. No existing rule changed.
- `CLAUDE.md` — an "Addressing" section, and the pre-flight check list is now
  four commands.
- `docs/MASTER_INDEX.md`, `README.md`, `docs/PROMPTS.md`, `docs/MIGRATION.md`
  (new Phase 4b), `_TEMPLATE-unit/INDEX.md` (`keywords:`), `/audit`, `/extend`,
  `/next`.

**Why**

The catalog layer solved *"which spec text do I need?"*. It left *"which file is
the thing the user just described?"* to a repo-wide grep — and a grep is the most
common way `App-Features.md` gets opened by accident, which is the single most
expensive mistake in the repo. `where.py` is cheaper than a grep and returns the
spec id too, so there is no incentive to reach for one.

**Upgrading from v3.1**

```bash
cp tools/where.py            your-project/tools/
cp docs/SURFACES.md          your-project/docs/
cp docs/CODE-LAYOUT.md       your-project/docs/
cp docs/00-PROTOCOL.md       your-project/docs/     # v2.0 -> v2.1
cp .claude/commands/where.md your-project/.claude/commands/
```

Then merge the "Addressing" section of this `CLAUDE.md` into yours, set
`code_roots:` in `SURFACES.md`, add `keywords:` to your unit `INDEX.md` files,
and run `python3 tools/where.py --check`. Nothing in the catalog, backlog or
unit docs needs to change.

## v3.1 — the feature-catalog layer

Catalog addressed by permanent id (`tools/spec.py`), `MODE: INGEST`,
`features-scan.py`, `DROPPED.md`.
