# AI-Ready Docs Skeleton v3.7

A documentation structure for projects an AI agent works on daily, sized for
**big, long-lived, complex** codebases where the spec is thousands of lines and
context is the scarcest resource.

v3 added the **feature-catalog layer**: a machine-readable spec that an agent
addresses by id instead of reading.

v3.2 added the **addressing layer**: you say *"edit the profile button in the
panel"* and the agent resolves it to a unit, a file and a spec id in one
command. No paths, no grep.

v3.7 adds the **walk**. Addressing answers *"where is this thing"*. It cannot
answer *"cookie login doesn't work"*, because that names no place — it names a
symptom plus a guess. v3.2 scored those against each other and returned a
shortlist, and a shortlist is what an agent reads its way out of. Now the chain
already in `depends_on` gets walked instead: `panel -> auth -> session`, three
hops, one predicted file each. See "When something breaks" below.

---

## The problem it solves

A serious product spec is 1500–4000 lines. An agent that reads it on every task
burns its context on text it does not need, keeps roughly half, and invents the
rest. So the catalog is never read. It is **indexed**, and each feature is
**addressed by a permanent id**.

The cost of one feature session:

| | without this | with this |
|---|---|---|
| spec read | the whole catalog | one `###` block, ~40–120 lines |
| how it is found | scanning / guessing | `python3 tools/spec.py F-0705` |
| survives a catalog edit | no — line numbers shift | yes — ids never move |

That last row is the important one. **Nothing outside the catalog ever stores a
line number.** Backlog rows cite ids; `spec.py` re-derives the location on every
call. A catalog rewrite cannot rot a single backlog row.

---

## Install

```bash
cp -r docs-skeleton/docs   your-project/docs
cp -r docs-skeleton/tools  your-project/tools
cp    docs-skeleton/AGENTS.md docs-skeleton/CLAUDE.md your-project/
cd your-project
python3 tools/docs-check.py        # 0 errors on a fresh skeleton
```

Then, in order:

0. Set `code_roots:` in `docs/SURFACES.md` front matter to your real source
   roots, and read `docs/CODE-LAYOUT.md` — it is one rule (unit id = folder
   name) and it is what makes every path derivable instead of memorised.
1. Fill `docs/GLOSSARY.md` **first**. Names are the backbone — if `user`,
   `customer` and `account` are not unified now, they become three tables.
2. Write `docs/features/App-Features.md` per `docs/FEATURES-FORMAT.md`
   (hand that file plus your feature list to a model — the prompt is in §10 of it).
3. `python3 tools/features-scan.py --check` until it exits 0.
4. Fill `docs/MASTER_INDEX.md` with your units.
5. Run MODE: INGEST for the first area you will build.
6. Add a `docs/SURFACES.md` row for each surface as you build it, and
   `keywords:` to each unit's `INDEX.md` — the words you would actually say for
   that unit. This is what makes `/where` work.
7. Run `/next`, repeatedly.

Already have a spec you did not write in this format? Start at
`docs/MIGRATION.md` instead — it covers phases 0–4 above in detail.

---

## Layout

```
AGENTS.md               the rules, canonical. every agent reads this one.
CLAUDE.md               `@AGENTS.md` + Claude Code's slash commands.

docs/
  AGENT-SETUP.md        per-tool setup, and how to run this with no filesystem
  00-PROTOCOL.md        FIXED. the rules every agent obeys. do not edit.
  FEATURES-FORMAT.md    FIXED. the contract the catalog must satisfy.
  MASTER_INDEX.md       one line per unit. entry point for every task.
  HANDOFF.md            mid-item session state. overwritten, never appended.
  SURFACES.md           user-visible thing -> unit -> file. entry point for a vague request.
  CODE-LAYOUT.md        the mirror rule, + symptom -> role: which file, not just which unit.
  CONVENTIONS.md        house style, C-nn ids, and what is actually enforced.
  BACKLOG.md            one row per shippable feature. built vs not built.
  GLOSSARY.md           canonical names. one term = one meaning.
  PROMPTS.md            copy-paste prompts.
  MIGRATION.md          how to fold an existing spec into the catalog.

  features/             the product spec — NEVER read whole
    App-Features.md     hand-written, in FEATURES-FORMAT shape
    MANIFEST.md         GENERATED. id -> block -> line range.
    DROPPED.md          catalog ids deliberately not built, with reasons.

  domains/              business logic, owns state
  interfaces/           what the outside world touches
  platform/             cross-cutting, no business rules
  _TEMPLATE-unit/       copy this to start a unit
  architecture/         overview, tech-stack, dependency-graph, decisions/
  operations/           environments, migrations, observability
  security/             threat model

.claude/commands/       slash commands: /where /diagnose /next /handoff /resume
                        /ingest /reconcile /audit /extend

tools/
  conventions.py        enforces docs/CONVENTIONS.md mechanically
  context.py            paste-ready session bundle for chat/API use
  drift.py              what changed in code since docs/.sync, and who owns it
  docs-check.py         enforces the protocol mechanically
  backlog.py            progress + what is eligible next
  features-scan.py      indexes + validates the catalog
  spec.py               id -> exactly the spec text needed
  where.py              a human sentence -> unit and file, or a path to walk
```

---

## Talking to it

You should never have to type a path. You point at a thing the way you would
point at it out loud:

```bash
python3 tools/where.py "edit the profile button in the panel"
```

```
confident match

[SURFACE] panel-profile-edit   unit: panel
    route   /panel/settings/profile
    code    apps/panel/src/features/profile/EditProfileButton.tsx
    spec    F-0111   ->  python3 tools/spec.py F-0111

next:
  1. read docs/interfaces/panel/INDEX.md  (tier 1), then contract.md + invariants.md
  2. python3 tools/spec.py F-0111
  3. edit only the code paths above. Do not open docs/features/App-Features.md.
```

Three outcomes, and the difference between them is the point:

| outcome | what happens |
|---|---|
| **confident match** | the agent announces the unit and files, then works |
| **candidates** | it asks which one. One question beats one wrongly-edited file |
| **nothing matches** | the surface has no row. You point at it once, the row is added with your words, and it is never asked again |

The map improves under use instead of decaying: every miss becomes an alias in
the same turn as the fix. That is its whole maintenance cost — and it is a
queue, not a reminder: a miss is written to `docs/.where-misses`, and
`where.py --check` (already in the pre-flight list) fails while one is open.

---

## When something breaks

A bug report is not a search. You say what broke, not where it lives:

```bash
python3 tools/where.py --walk "cookie login doesn't work"
```

```
walk plan   entry: panel-login   hypothesis: cookie

  hop 0   panel     (interface, entry point)
  hop 1   auth      (domain, via depends_on)
  hop 2   session   (platform, via depends_on)
  hop 3   identity  (domain, via depends_on)
```

The sentence is split in two and the halves are used differently. `login` is the
**locator** — where you saw it — and it alone picks the entry point. `cookie` is
your **hypothesis**, and it only reorders the frontier: notice `session` ranked
above `identity` because its keywords mention cookies. A guess that reorders a
walk costs nothing when it is wrong; a guess that picks the entry point starts
the session in the wrong unit, confidently.

Three things keep the walk from becoming a read-everything:

| | |
|---|---|
| **a prediction per hop** | one line of *what you expect to find*, before opening it. A hop you cannot predict is a hop you are not ready to take. Wrong hypotheses announce themselves; bulk reading never does |
| **symptom -> role** | inside a unit, `CODE-LAYOUT.md` maps 401 to the guard, wrong values to the service, bad writes to the repository. One file per hop, not thirty |
| **3 hops, 8 files** | the ceiling, not the mechanism |

Asynchronous edges are walked too. A queue or webhook moves control without
either unit importing the other, so `depends_on` is blind to it — those live in
a separate `## Runtime edges` table and are never merged into `depends_on`,
which would inflate every consumer list and make additive changes look breaking.

When the bug is fixed the path is written down as a `Flows` row, using your own
sentence as the alias. Rows are never authored in advance: one written before
the walk is a guess at which files matter, and it is wrong in the worst way —
it looks like knowledge. The second report of the same bug skips the walk.

---

## Any model, any tool

Nothing here is Claude-specific: plain Markdown and four dependency-free Python
scripts. `AGENTS.md` is the canonical rules file, read natively by Codex,
Cursor, Copilot, Gemini CLI, Aider, Zed and others; `CLAUDE.md` is one
`@AGENTS.md` line plus Claude Code's slash commands. Point any other tool's
rules file at `AGENTS.md` — never copy it, or the two drift within a month.

On a plain chat window or a raw OpenRouter call the agent has no shell, so you
run the tools and paste:

```bash
python3 tools/context.py --lean     # ~3k tokens: protocol digest + index + backlog + handoff
```

Once per session, not per message. `docs/AGENT-SETUP.md` covers both cases,
including the one thing that genuinely does not port: the protocol works by
obedience, and a cheap model will grep the repo the moment it feels lost. That
page says what to do about it.

---

## The three loops

**INGEST** — catalog → backlog, one area at a time, the day you start that area.
An area you are not building costs nothing.

**SYNC** — you coded for a week without an agent. `tools/drift.py` diffs the
code against `docs/.sync` and produces a small work order: which units were
touched, which code no unit claims, which doc paths no longer resolve, which
surfaces are new. Cheap and incremental, where RECONCILE is a one-time sweep.

**HANDOFF / RESUME** — the session boundary. `BACKLOG.md` + `MASTER_INDEX.md`
resume you *between* items; `HANDOFF.md` resumes you *inside* one, carrying the
three things that otherwise die with the session: what is half-written, what was
already tried and failed, and what got decided out loud but never written down.

**NEXT** — backlog → code, one row per session. Reads the unit's docs plus one
`spec.py` call. Stops. A fresh session with zero context resumes correctly.

**LOCATE** — your sentence → a unit and a file, before any reading happens.
Runs first whenever a request has no path in it, which is most of them.

**DIAGNOSE** — your symptom → an ordered walk through units. Entry point comes
from where you saw it; your guess about the cause only reorders the walk. Three
hops, eight files, one line of prediction before each hop. The path it took is
written down at the end, so the second report of the same bug costs one command.

**AUDIT** — proves nothing drifted: no unit lies about being implemented, no
backlog row cites a catalog id that does not exist, no catalog feature is
missing from both the backlog and `DROPPED.md`.

---

## Why it does not rot

| Rot | What stops it |
|---|---|
| docs claim a feature exists, code disagrees | `status: active` requires non-empty `source:` whose paths resolve — `docs-check.py` fails otherwise |
| spec refs break when the catalog is edited | refs are ids, never line numbers; `spec.py` re-derives |
| a feature silently disappears | `--check` coverage: every catalog id is in the backlog or in `DROPPED.md` |
| duplicated facts diverge | never duplicate what lives in code; link to it (§0 authority order) |
| the backlog fills with unstartable epics | one row = one sitting; `--check` warns on oversized blocks |
| an agent reads everything and keeps nothing | tiered read protocol, §3, with hard limits |
| you code for a week alone and the docs quietly go stale | `drift.py` against a committed `.sync` marker — the gap is measured, not guessed |
| a `source:` glob quietly swallows a whole app | `drift.py` flags any glob that does not contain its own unit id |
| a session dies mid-feature and the next one starts over | `HANDOFF.md` — and `backlog.py` fails on one that outlived its item |
| a house rule that only lives in prose gets quietly dropped | `CONVENTIONS.md` `check` blocks — and a `enforced by` column that admits which rules are only hoped for |
| an agent greps the repo and trips over the catalog | `where.py` is cheaper than a grep and returns the spec id too, so there is no incentive to |
| the surface map drifts from the code | `where.py --check` fails on a component path that no longer exists |
| the map never matches how you actually speak | every miss is queued in `.where-misses`; `where.py --check` fails while one is open |
| a bug report turns into "read everything about auth" | it has its own mode (§6g) and its own budget: 3 hops, 8 files, a prediction before each |
| a walk stops at a queue and calls the graph clean | runtime edges are a separate table, walked alongside `depends_on` |
| the same bug is re-investigated from scratch every time | the walk is cached as a Flows row, written from the path actually taken |
| a decision gets re-litigated every quarter | ADRs and catalog `C-nn` rows record what was chosen and why |

---

## Validate anytime

```bash
python3 tools/docs-check.py             # front matter, source: paths, reachability
python3 tools/backlog.py                # progress, deps, next eligible
python3 tools/features-scan.py --check  # catalog format + coverage
python3 tools/spec.py --todo            # what is not ingested yet
python3 tools/where.py --check          # every surface resolves to a real file
python3 tools/conventions.py            # house style, mechanically
python3 tools/drift.py                  # code that moved past the docs
```

Wire the four into CI. A skeleton nobody checks is just more markdown to rot.
